#!/usr/bin/env bash
java -Djava.library.path=./lib -jar Grimoire-Standalone.jar
